/***********************************************************************
 * livre.c
 * bdh 
 * Ven  2 déc 2016 09:33:31 CET
 ***********************************************************************/
#include "livre.h"

static int taille = 0;
static int nbreL = 0;

Livre str2Livre(char *s){
	Livre l;
	char * token;
	int i;

	for (i=0, token=strtok(s, ";"); token != NULL;  i++, token=strtok(NULL, ";\n")){
		switch (i){
		case TITRE:
			strcpy(l.titre, token);
			break;
		case AUTEUR:
			strcpy(l.auteur, token);
			break;
		case ISBN:
			l.isbn = strtol(token, NULL, 10);
			break;
		case EDITEUR:
			strcpy(l.editeur, token);
			break;
		case ANNEE:
			l.an = strtol(token, NULL, 10);
			break;
		case GENRE:
			l.genre = setGenre(token);
			break;
		}
	}
	return l;
}


char * livre2str(char *s, Livre l){
	sprintf(s, "%-50s %-20s %ld %-20s %d %s", l.titre, l.auteur, l.isbn, l.editeur, l.an, getGenre(l.genre));
	return s;
}

int addLivre( Livre **bib, Livre l){

	if (taille == 0){
		if ((*bib = (Livre*)malloc((taille=3)*sizeof(Livre))) == NULL){
			perror("Malloc");
			exit(20);
		}
	} else if (taille == nbreL){
		if ((*bib = (Livre*)realloc(*bib, (taille*=2)*sizeof(Livre))) == NULL){
			perror("Realloc");
			exit(20);
		}
	}
	(*bib)[nbreL++] = l;
	return nbreL;
}

int comparerLivre(Livre*a, Livre*b){
	int auxComp;
	if (a->an != b->an)
		return a->an - b->an;
	if (auxComp =strcmp(a->editeur,b->editeur))
		return auxComp;
	return strcmp(a->auteur,b->auteur);
}


void afficherBib(Livre* bib, int t){
	Livre *ptr=NULL;
	char ligne[256];


	printf("Voici ma bib de %d livres\n", t);
	for (ptr = bib; ptr < bib+t; ptr++){
		printf("\t%s\n", livre2str(ligne, *ptr));
	}
	printf("---------------------------\n");
	return;
}

enum Genre setGenre(char *s){
	enum Genre g = BD;
	char **ptr = NULL;

	for (ptr = lesGenres; *ptr != NULL; ptr++, g++){
		if (!strcmp(s, *ptr)){
			return g;
		}
	}
	return KO;
}

char *getGenre(enum Genre g){
	return lesGenres[g];
}


void freeBiblio(Livre **bib){

	free(*bib);
	*bib = NULL;
	taille = 0;
	nbreL = 0;
	

}

