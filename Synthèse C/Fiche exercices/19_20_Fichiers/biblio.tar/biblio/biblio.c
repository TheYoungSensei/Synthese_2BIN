/***********************************************************************
 * biblio.c
 * bdh 
 * Dimanche, 20 nov 2016 
 ***********************************************************************/
#include "livre.h"

int lireFichier(FILE *, Livre**);
int ecrireFichier(FILE *, Livre*, int );

int main (int argc, char **argv){
	Livre *maBib= NULL;
	char ligne[257];
	Livre unLivre;
	int nbreLivre = 0;
	FILE *fin = NULL;
	FILE *fout = NULL;

	/* usage et gestion des fihciers*/
	switch(argc) {
		default : fprintf(stderr, "Usage : %s [fin] fout \n", *argv);
			  exit(1);
		case 3 : if ((fin = fopen(*++argv, "r")) == NULL){
				 perror("ouverture de fin");
				 exit(10);
			 } else {
				 nbreLivre = lireFichier(fin, &maBib);
			 }
		case 2 : if ((fout = fopen(*++argv, "w")) == NULL){
				 perror("ouverture de fout");
				 exit(11);
			 }
			 break;
	}

	while (fgets(ligne, 256, stdin)){
		unLivre = str2Livre(ligne);
		nbreLivre = addLivre(&maBib, unLivre);
	}
	afficherBib(maBib, nbreLivre);
	qsort(maBib, nbreLivre, sizeof(Livre), (fctcmp)comparerLivre);
	afficherBib(maBib, nbreLivre);
	ecrireFichier(fout, maBib, nbreLivre);
	freeBiblio(&maBib);
}

int lireFichier(FILE *f, Livre** bib){
	Livre l;
	int taille;
	int nbrEnreg;

	while((nbrEnreg = fread(&l, sizeof(Livre), 1, f)) == 1) {
		taille = addLivre(bib, l);
	}
	if((nbrEnreg != 1) && !feof(f)){
		perror("probleme de lecture");
		exit(12);
	}
	return taille;
}

int ecrireFichier(FILE *f, Livre* bib, int n){
	Livre l;
	Livre *ptr;
	int i;

	for (ptr = bib; ptr < bib+n; ptr++){
		if((i=fwrite(ptr, sizeof(Livre), 1, f)) != 1) {
			perror("ecrire");
			exit(13);
		}
	}
	return 1;
}

