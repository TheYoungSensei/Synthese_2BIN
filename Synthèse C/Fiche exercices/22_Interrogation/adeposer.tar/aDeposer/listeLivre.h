/***********************************************************************
 * listeLivre.h
 * NOM 
 * PRENOM 
 * 19 dec 2016
 ***********************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#if !defined (_LISTELIVRE_H_)
#define _LISTELIVRE_H_

enum Genre {BD, PO, TH, RO, RH, LF, LE, SC, IN, SF, SA, HI} ;

/* définition du type structure d'un livre */
typedef struct {
	char titre[128];
	char auteur[80];
	long isbn;
	char editeur[50];
	int an;
	enum Genre genre;
} Livre;

/* définition du type récursif  Noeud */
typedef struct noeud {
	Livre livre;
	struct noeud* svt;
} Noeud;

#define KO -1


/* initialise la liste en renvoyant une liste vide */
/*    ici un pointeur NULL */
Noeud *initListe();


/* Fonction qui convertit une chaine de caractères en une structure Livre*/
/*     le séparateur entre champs est le ':' */
Livre str2Livre(char *);

/* Fonction qui convertit une structure en une chaine de caractères */
char * livre2str(char *, Livre);

/* Fonction qui insere un Noeud dans la liste en gardant celle-ci triée */
int inserer(Livre, Noeud**);

/* Fonction qui affiche le contenu de la liste */
void afficherListe(char *, Noeud*);

/* Fonction qui convertit le genre sous forme de chaine	de catactères  */
/*    en une valeur de type enum */
enum Genre setGenre(char *);

/* Fonction qui ocnvertit un enum en chaine de caractères */
char *getGenre(enum Genre);
#endif

