public class MonException extends Exception {
}