public interface monInterface {

}