public class MonException extends Exception {

	public MonException() {
    	super();
    }
    
    public MonException(String message) {
    	super(message);
    }

}