package chengdu.exceptions;

public class ThisIsNotMyBatchException extends Exception {

	public ThisIsNotMyBatchException() {
		// TODO Auto-generated constructor stub
	}

	public ThisIsNotMyBatchException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ThisIsNotMyBatchException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public ThisIsNotMyBatchException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}



}
