package chengdu.exceptions;

public class MinimumMultiplicityException extends Exception {

	public MinimumMultiplicityException() {
		// TODO Auto-generated constructor stub
	}

	public MinimumMultiplicityException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public MinimumMultiplicityException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public MinimumMultiplicityException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
