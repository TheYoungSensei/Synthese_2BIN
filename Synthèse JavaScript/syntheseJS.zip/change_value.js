.nom="Muad'dib";
["nom"]="Kwisatz Haderach";