.nom // renvoie "Atreides"
["nom"] // renvoie "Atreides