<html>
...
<script type="application/javascript">
console.log('test');
</script>
...
</html>