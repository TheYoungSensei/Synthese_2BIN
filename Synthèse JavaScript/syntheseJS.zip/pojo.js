public class Person{
	privateString name;
	privateintage;
	privateAddressaddress;
	public Person() {} // constructeur sans argument
	public Person(String name, intage, Addressaddress) {
		this.name = name;
		this.age= age;
		this.address= address;
	}
	// getters & setters
}
	public class Address{
		public intbuilding;
		public String city;
		public Address() {}
		public Address(intbuilding, String city) {
		this.building= building;
		this.city= city;
	}
}