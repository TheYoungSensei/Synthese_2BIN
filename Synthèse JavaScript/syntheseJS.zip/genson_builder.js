Genson genson=new GensonBuilder()
.useDateFormat(new SimpleDateFormat("yyyy-MM-dd"))
.useIndentation(true)
.useConstructorWithArguments(true)
.create();