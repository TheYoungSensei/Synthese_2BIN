delete o.nom;
delete o["prenom"];
