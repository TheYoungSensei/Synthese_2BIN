var toto=createPerson("Toto","Blague");
toto.setAddress("rue de la blague, 10");
toto.setAge(7);
var jean=createPerson("Jean","Valjean");
jean.setAge(42);
